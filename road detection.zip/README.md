# Accident-detection-Project-
Accident detection using Image Processing 

Create an opencv environment on your system. 
Download opencv from the link given for appropriate operating system.
Go through opencv from http://opencv.org/
